#!/usr/bin/env python2.7
#--coding:utf-8 --
"""
"""

__author__ = "CAO Yaqiang"
__date__ = ""
__modified__ = ""
__email__ = "caoyaqiang0410@gmail.com"

#sys library
import os, time, sys, logging, gzip, argparse

#glob settings
#epilog for argparse
EPILOG = "Any bug is welcome reported to caoyaqiang@picb.ac.cn, chenxingwei@picb.ac.cn or aidaosheng@picb.ac.cn"


def getLogger(fn=None):
    """
    Creat the logger system.
    """
    #get the current time
    date = time.strftime(' %Y-%m-%d', time.localtime(time.time()))
    #if fn == None:
    #    fn = os.getcwd() + "/" + date.strip() + ".log"
    #set up logging, both write log info to console and log file
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s %(name)-6s %(levelname)-8s %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S',
        filename=fn,
        filemode='a')
    logger = logging.getLogger()
    handler = logging.StreamHandler(sys.stdout)
    formatter = logging.Formatter('%(asctime)s %(levelname)s %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.setLevel(logging.NOTSET)
    return logger


def callSys(cmds, logger=None):
    """
    Call systematic commands without return.
    """
    for c in cmds:
        try:
            logger.info(c)
        except:
            print c
        try:
            os.system(c)
        except:
            try:
                logger.error(c)
            except:
                print "ERROR!", c


def cFlush(r):
    """
    One line flush.
    """
    sys.stdout.write("\r%s" % r)
    sys.stdout.flush()


def mainHelp():
    """
    Create the command line interface of the main programme for calling loops.
    """
    epilog = EPILOG
    description = """
        Intra-chromosomal loops calling for ChIA-PET,HiChIP and high-resolution Hi-C data.
        """
    parser = argparse.ArgumentParser(description=description, epilog=epilog)
    parser.add_argument(
        "-f",
        dest="fnIn",
        required=True,
        type=str,
        help="Input file is mapped PETs, BEDPE format in gzip. Replicates could be input as -f A.bedpe.gz,B.bedpe.gz,C.bedpe.gz. Loops will be called with pooled data."
    )
    parser.add_argument(
        "-o", dest="fnOut", required=True, type=str, help="Output prefix.")
    parser.add_argument(
        "-eps",
        dest="eps",
        default=0,
        help="Distance that define two points being neighbors, eps in cDBSCAN as key parameter, default is auto estimation from the data as 2 fold of fragment size. Set 0 as auto, good for TFs ChIA-PET data. For broad peak like ChIA-PET data, such as H3K27ac/H3K4me1, set it to 2000. For data like HiChIP, set it larger,set several eps like 2000,5000,10000."
    )
    parser.add_argument(
        "-minPts",
        dest="minPts",
        default=5,
        type=int,
        help="Points required in a cluster, minPts in cDBSCAN, key parameter, default is 5. 5 is good for TFs and histone modification ChIA-PET data. For data like HiChIP, set it larger, like 10, 25, 50."
    )
    parser.add_argument(
        "-p",
        dest="cpu",
        required=False,
        default=1,
        type=int,
        help="CPU number used to run the job, default is 1,set -1 to use all cpus available. Too many CPU could cause memory error."
    )
    parser.add_argument(
        "-c",
        dest="chroms",
        required=False,
        default="",
        type=str,
        help="Whether to process limited chroms, specify it as chr1,chr2,chr3, default is not. Use this to filter reads in like chr22_KI270876v1_alt"
    )
    parser.add_argument(
        "-w",
        dest="washU",
        required=False,
        default=False,
        type=bool,
        help="Whether to save tracks of loops to visualize in washU. Default is No."
    )
    parser.add_argument(
        "-j",
        dest="juice",
        required=False,
        default=False,
        type=bool,
        help="Whether to convert loops to 2d feature annotations to visualize in Juicebox. Default is No"
    )
    parser.add_argument(
        "-s",
        dest="tmp",
        required=False,
        default=False,
        type=bool,
        help="Whether or not to save temp files for each chromosomes during processing. Set 1 for following calling differentially enriched loops or converting PETs to washU track or hic file load into juicebox. Default is not."
    )
    parser.add_argument(
        "-hic",
        dest="hic",
        required=False,
        default=False,
        type=bool,
        help="If input is HiChIP or high resolution Hi-C data, set this to 1, using different significance cutoffs for loops than ChIA-PET data."
    )
    parser.add_argument(
        "-cut",
        dest="cut",
        required=False,
        default=0,
        type=int,
        help="Initial distance cutoff to filter PETs, default is 0. Keep this as default when using auto mode to estimate eps."
    )
    op = parser.parse_args()
    return op


def deloopHelp():
    """
    Create the command line interface for the script of deLoops 
    """
    epilog = EPILOG
    description = """
        Differentially enriched loops calling based on loops called by cLoops.
        """
    parser = argparse.ArgumentParser(description=description, epilog=epilog)
    parser.add_argument(
        "-fa",
        dest="fa",
        required=True,
        type=str,
        help="Loops file called by cLoops. Only using significant loops as mark 1, you can change this in the .loop file."
    )
    parser.add_argument(
        "-fb",
        dest="fb",
        required=True,
        type=str,
        help="Loops file called by cLoops.")
    parser.add_argument(
        "-da",
        dest="da",
        required=True,
        type=str,
        help="Directory for .jd files of loop file a, generated by cLoops with option -s 1."
    )
    parser.add_argument(
        "-db",
        dest="db",
        required=True,
        type=str,
        help="Directory for .jd files of loop file b, generated by cLoops with option -s 1."
    )
    parser.add_argument(
        "-p",
        dest="cpu",
        required=False,
        default=1,
        type=int,
        help="CPU number used to run the job, default is 1,set -1 to use all cpus available. Too many CPU could cause memory error."
    )
    parser.add_argument(
        "-c",
        dest="chroms",
        required=False,
        default="",
        type=str,
        help="Whether to process limited chroms, specify it as chr1,chr2,chr3, default is not. Set it to the same one for cLoops."
    )
    parser.add_argument(
        "-dis",
        dest="dis",
        required=False,
        default=0,
        type=int,
        help="Set a distance cutoff to filter PETs, could be the inter-ligation and self-ligation cutoff, default is 0."
    )

    op = parser.parse_args()
    return op


def jd2washUHelp():
    """
    Create the command line interface for the script of jd2washU.
    """
    epilog = EPILOG
    description = """
        Convert PETs level data to washU browser track for visualization. bedtools,bgzip,tabix are required.
        """
    parser = argparse.ArgumentParser(description=description, epilog=epilog)
    parser.add_argument(
        "-d",
        dest="dir",
        required=True,
        type=str,
        help="Directory for .jd files, generated by cLoops with option -s 1.")
    parser.add_argument(
        "-o", dest="output", required=True, type=str, help="Output prefix.")
    parser.add_argument(
        "-ext",
        dest="ext",
        type=int,
        default=75,
        help="Extension from the middle center of the PET to both ends,default is 75."
    )
    parser.add_argument(
        "-cut",
        dest="cut",
        type=int,
        default=0,
        help="Distance cutoff for PETs to filter, default is 0.")

    op = parser.parse_args()
    return op


def jd2juiceHelp():
    """
    Create the command line interface for the script of jd2juice.
    """
    epilog = EPILOG
    description = """
        Convert PETs level data to .hic file to load in juicebox. The command "juicer_tools pre" is required in the enviroment.
        """
    parser = argparse.ArgumentParser(description=description, epilog=epilog)
    parser.add_argument(
        "-d",
        dest="dir",
        required=True,
        type=str,
        help="Directory for .jd files, generated by cLoops with option -s 1.")
    parser.add_argument(
        "-o", dest="output", required=True, type=str, help="Output prefix.")
    parser.add_argument(
        "-org",
        dest="org",
        required=True,
        type=str,
        default="hg38",
        help="Organism required to generate .hic file,default is hg38.")
    parser.add_argument(
        "-cut",
        dest="cut",
        type=int,
        default=0,
        help="Distance cutoff for PETs to filter, default is 0.")
    op = parser.parse_args()
    return op
